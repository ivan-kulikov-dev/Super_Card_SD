Update(2008.03.18)
firmware 1.85 released
ALL SUPERCARD SLOT2 series
Fixed: the MoD (Moogles of Death) Thank You screen of 2107

Q:How to upgrade the firmware?
A:Download it and unzip it into root directory of TF/SD card;turn on ds and run it as run a game.Make sure it cannot be turned power off when upgading!

Q:My firmware is too old,may I upgrade it to the newest directly?
A:It is absolutely decided by the postfix name:
.BIN (FULL firmware,it is able to be upgraded to the newest directly)
.SCU (PATCHED firmware,it needs to be upgraded to the newer step by step;otherwise you will get two white screens.)


Q:Why does it appeare English ...... XXXX after being coped firmware files?
A:Because maybe you are using SC of English Version;firmware(Chinese version) could not be used with SC (English version).Up to now,there are different between SCL series and SC rumble series according to firmware in SC SLOT 2 series.SC (English version) must use firmware(English version);SC (Chinses version) should use Firmware(Chinese version).






